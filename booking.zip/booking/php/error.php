<?php
require 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    body{
        padding:30px;
        font-family:helvetica;
    }
    h1{
        color:red;
    }
    </style>
</head>
<body>
    <h1>Oops!</h1>
<?php
$error = $_REQUEST['error'];
$from = $_REQUEST['from'];
echo "<p>$error</p>";
echo "<a href='$from'>Go back</a>";
?>
</body>
</html>