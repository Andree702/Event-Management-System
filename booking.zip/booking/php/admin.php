<?php
require "db_connect.php";//Getting database connection for this page to be able to acces database
if(!$_SESSION['admin']){
	header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="../css/profile.css">
	<script src="../js/jquery.js"></script>
	<style>
    header p {
		margin-bottom:50px;
	}
	.header{
		text-align:center;
		margin-bottom:20px;
	}
 div a{
	 display:inline-block;
	 margin-top:5px;
 }
	header nav {
		float:none;
	}
	
	@media(min-width:1000px){
		header nav{
			float:right;
		}
		header p{
			margin-bottom:-10px;
		}
	}
	</style>
</head>
<body>
<header>
<p> <a href="../index.php">Booking.com</a></p>
	<nav>
		<a href="admin_set.php">Set password</a>
		<a href="add.php">Create event</a>
		<a href="admin_logout.php">Logout</a>
</nav>
</header>
<h1 class='header'>Posted events are shown below</h1>

<?php
//Show any operation made by this file, if successful
if($_REQUEST['success']){
	echo "<p class='msg'>".$_REQUEST['success']."</p>";
}

$query_events = sprintf("SELECT * FROM event_org;");//SQL for retrieving event saved
$result = mysqli_query($conn,$query_events);
while($row = mysqli_fetch_array($result)){
	$id = $row["event_id"];
	$title = $row['title'];
	$location = $row['location'];
	$date = $row["date"];
	$start_time = $row['start'];
	$end_time = $row['endt'];
	$status = $row["status"];
	$description = $row["description"];
//Counting the number of people who sign up for this event
$query_books = sprintf("SELECT * FROM books WHERE event_id2=%d;",$id);
$result_books = mysqli_query($conn,$query_books);
$number_of_books = mysqli_num_rows($result_books);

//Displaying the information retrieved from the database
echo "<div>
<h1>$title</h1>
<ul>
<li><b>Location </b>$location</li>
<li><b>Date </b>$date</li>
<li><b>Start-time </b>$start_time</li>
<li><b>End-time </b>$end_time</li>
<li><b>Details </b>$description</li>
</ul>
<a href='view.php?id=$id'><img src='../img/eye.png'>View number of people($number_of_books)</a><br>
<a href='delete_event.php?id=$id' class='del'><img src='../img/cancel.png'>Delete event</a><br>";
if($status == 'paused'){
	echo "<a href='remove_paused.php?id=$id'><img src='../img/play.png'>Unpause event</a>";
}else{
echo "<a href='pause.php?id=$id'><img src='../img/pause.png'>Pause event</a>";
}
echo "</div>";
}

?>
<script>
	$(document).ready(function(){
    $('.msg').fadeOut(900).fadeIn(900).fadeOut(800);

	$('.del').click(function(evt){
    var con  = confirm('Do you really want to delete this post');
     if(!con){
		 evt.preventDefault();
	 }
})//end click

	})//end ready
</script>
</body>
</html>