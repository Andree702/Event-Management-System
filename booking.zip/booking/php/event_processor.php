<?php
require "db_connect.php";
//if the session admin is not set, no permision is given to this file
if(!$_SESSION['admin']){
	header("location:../index.php");
}
//Retrieving the new event values
$title = $_REQUEST["title"];
$location = $_REQUEST["location"];
$date = $_REQUEST["date"];
$start_time = $_REQUEST["start"];
$end_time = $_REQUEST["end"];
$desc = $_REQUEST["desc"];
$status = 'on';
if($title){
	//Query for saving new event
	$query = sprintf("INSERT INTO event_org(title,location,date,start,endt,description,status) VALUES('%s','%s','%s','%s','%s','%s','%s');",mysqli_real_escape_string($conn,$title),mysqli_real_escape_string($conn,$location),mysqli_real_escape_string($conn,$date),mysqli_real_escape_string($conn,$start_time),mysqli_real_escape_string($conn,$end_time),mysqli_real_escape_string($conn,$desc),$status);

	$result = mysqli_query($conn,$query);
	header("location:admin.php?success=Operation successful");//Redirecting admin to admin page
}

?>