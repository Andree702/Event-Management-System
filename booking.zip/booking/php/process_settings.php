<?php
require "db_connect.php";//Requiring database connection file 
//new variables entered by user
$id = $_SESSION['id'];
$number = $_REQUEST['number'];
$password = trim($_REQUEST['password']);
$encryptedPassword = openssl_encrypt($password,'seed','lock');//Encrypting password
//if the user enters new telephone number update it
if($number){
$query = sprintf("UPDATE users SET number='%s' WHERE id=%d;",mysqli_real_escape_string($conn,$number),$id);
$result = mysqli_query($conn,$query);
}
//if the user enters new password number update it
if($password){
$query1 = sprintf("UPDATE users SET password='%s' WHERE id=%d;",mysqli_real_escape_string($conn,$encryptedPassword),$id);
$result1 = mysqli_query($conn,$query1);
}

header("location:profile.php?success=Operation successful");
?>