<?php
session_start();
unset($_SESSION['admin']);//Clearing session admin variable
header("location:admin_auth.php");
?>