<?php
require 'db_connect.php';//Getting database connection file
//Retrieving new user's information
$name = $_REQUEST["name"];
$email = $_REQUEST["email"];
$password = $_REQUEST["password"];
$encryptedPassword = openssl_encrypt($password,'seed','lock');//Encrypting users password

$number  = $_REQUEST["number"];
$about = $_REQUEST["about"];
//SQL query for inserting new users's information
$query = sprintf("INSERT INTO users(name,email,password,number,about) VALUES('%s','%s','%s','%s','%s');",mysqli_real_escape_string($conn,$name),mysqli_real_escape_string($conn,$email),mysqli_real_escape_string($conn,$encryptedPassword),mysqli_real_escape_string($conn,$number),mysqli_real_escape_string($conn,$about));

$result = mysqli_query($conn,$query);//passing query into database

$id = mysqli_insert_id($conn);//Saving the id of the current user

$_SESSION["id"] = $id;//Saving the id of the user id in a session to enable users to perfom all user's activicties on profile page.
/*Saving the user id in session makes the id accessible to all other files that make may require the id*/

header("location:profile.php");//After this file has finished the above lines of code, it redirect the user to the profile. 
?>