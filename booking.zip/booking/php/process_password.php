<?php
require "db_connect.php";//Requiring database connection file 
//if the session admin is not set, no permision is given to this file
if(!$_SESSION['admin']){
	header("location:../index.php");
}
if($_REQUEST['password']){
	$password = trim($_REQUEST['password']);
	$password = openssl_encrypt($password,'seed','lock');
}
//Updating admin password
$query = sprintf("UPDATE ad_pass SET pass='%s';",mysqli_real_escape_string($conn,$password));
$result = mysqli_query($conn,$query);
if($result){
	header("location:admin.php?success=Operation successful");
}
?>