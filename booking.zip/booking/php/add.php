<?php
require "db_connect.php";
//if the session admin is not set, no permision is given to this file
if(!$_SESSION['admin']){
	header("location:../index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Add event</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="../css/forms.css">
	<style>
		.p{
			margin-bottom:30px;
		
		}
		.p a{
			color:hsl(210,100%,50%);
		}
	</style>
</head>
<body>
<header>
	
</header>
<p  class="p"><a href="admin.php">Back to Admin</a></p>
<form method="post" action="event_processor.php">
	<ul>
		<li>
			<label>Title</label>
			<input type="text" name="title">
		</li>
		<li>
			<label>Location</label>
			<input type="text" name="location">
		</li>
		<li>
			<label>Date</label>
			<input type="date" name="date">
		</li>
		<li>
			<label>Start-time</label>
			<input type="time" name="start">
		</li>
		<li>
			<label>End-time</label>
			<input type="time" name="end">
		</li>
		<li>
			<label>Description  of event</label>
			<textarea name="desc"></textarea>
		</li>
		<li>
		
			<input type="submit" value="Create">
		</li>
	</ul>
</form>
</body>
</html>