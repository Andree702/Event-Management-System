<?php
error_reporting(0);//Suppressing error
session_start();
require 'config.php';//Getting the constant variables for database connection
$conn = mysqli_connect(HOST,USER,PASSWORD) or die("nono");//Code for host connection
mysqli_select_db($conn,DATABASE) or die("nionoooon");//Selecting the databsae
?>