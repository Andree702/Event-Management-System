<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bookings</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<script src="js/jquery.js"></script>
</head>
<body>
	<div class="parent">
<header>
	<p>Booking.com</p>
	<nav>
		<ul>
			<li><a href="php/login.php">Login</a></li>
			<li><a href="php/about_us.html">About us</a></li>
			<li><a href="php/faq.html">FAQ</a></li>
		</ul>
	</nav>
</header>
<article>
	<h1>Welcome, please sign up below if you are new here to start reservation.</h1>
	<form method="get" action="php/sign.php">
		<img src="img/user.jpg">
		<ul>
			<li>
				<label>User name</label>
				<input type="text" name="name">
			</li>
			<li>
				<label>Email</label>
				<input type="email" name="email">
			</li>
			<li class='pass'>
				<img src="img/eye.png" class='eye'>
				<img src="img/lock.png" class='lock'>
				<label>Password</label>
				<input type="password" name="password">
			</li>
			<li>
				<label>Telephone number</label>
				<input type="number" name="number">
			</li>
			<li>
				<label>About me</label>
				<textarea name="about"></textarea>
			</li>
			<li class="sign">
				<input type="submit" value="Sign up">
			</li>
		</ul>
	</form>
</article>
<footer>
	<p>Copyright &#169 booking.com</p>
</footer>
</div>
<script>
	$(document).ready(function(){
		/*Functionalities for showing and hiding password*/
    $(".pass .eye").click(function(){
    $(".pass input").attr('type','text');
	$(this).hide();
	$(".pass .lock").show();
	})//end click

	$(".pass .lock").click(function(){
    $(".pass input").attr('type','password');
	$(this).hide();
	$(".pass .eye").show();
	})//end click
	})//end ready
</script>
</body>
</html>